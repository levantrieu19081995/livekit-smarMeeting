package vn.cusc.meetingservice.dto.request;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import java.time.LocalDateTime;
import java.util.List;
import vn.cusc.meetingservice.model.enums.MeetingAccessType;

public record CreateMeetingRequest(
    @NotBlank(message = "title is required") String title,
    String description,
    @NotNull(message = "startTime is required") LocalDateTime startTime,
    @NotNull(message = "endTime is required") LocalDateTime endTime,
    @NotNull(message = "accessType is required") MeetingAccessType accessType,
    @Valid List<AddMeetingParticipantRequest> participants
) {
}
