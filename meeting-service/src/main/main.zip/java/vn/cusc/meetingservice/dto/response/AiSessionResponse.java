package vn.cusc.meetingservice.dto.response;

import java.time.LocalDateTime;
import vn.cusc.meetingservice.model.enums.AiSessionStatus;

public record AiSessionResponse(
    Long id,
    String externalSessionId,
    AiSessionStatus status,
    LocalDateTime startedAt,
    LocalDateTime finishedAt,
    String errorMessage
) {
}
