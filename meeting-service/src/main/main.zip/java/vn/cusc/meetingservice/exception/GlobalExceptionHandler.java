package vn.cusc.meetingservice.exception;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.ConstraintViolationException;
import java.time.LocalDateTime;
import java.util.stream.Collectors;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice
public class GlobalExceptionHandler {

    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<ErrorResponse> handleValidation(MethodArgumentNotValidException exception, HttpServletRequest request) {
        String message = exception.getBindingResult().getFieldErrors().stream()
            .map(FieldError::getDefaultMessage)
            .collect(Collectors.joining("; "));
        return build(HttpStatus.BAD_REQUEST, "VALIDATION_ERROR", message, request.getRequestURI());
    }

    @ExceptionHandler(ConstraintViolationException.class)
    public ResponseEntity<ErrorResponse> handleConstraint(ConstraintViolationException exception, HttpServletRequest request) {
        return build(HttpStatus.BAD_REQUEST, "CONSTRAINT_VIOLATION", exception.getMessage(), request.getRequestURI());
    }

    @ExceptionHandler(MeetingNotFoundException.class)
    public ResponseEntity<ErrorResponse> handleMeetingNotFound(MeetingNotFoundException exception, HttpServletRequest request) {
        return build(HttpStatus.NOT_FOUND, "MEETING_NOT_FOUND", exception.getMessage(), request.getRequestURI());
    }

    @ExceptionHandler(ParticipantNotFoundException.class)
    public ResponseEntity<ErrorResponse> handleParticipantNotFound(ParticipantNotFoundException exception, HttpServletRequest request) {
        return build(HttpStatus.NOT_FOUND, "PARTICIPANT_NOT_FOUND", exception.getMessage(), request.getRequestURI());
    }

    @ExceptionHandler(ParticipantAlreadyExistsException.class)
    public ResponseEntity<ErrorResponse> handleParticipantAlreadyExists(ParticipantAlreadyExistsException exception, HttpServletRequest request) {
        return build(HttpStatus.CONFLICT, "PARTICIPANT_ALREADY_EXISTS", exception.getMessage(), request.getRequestURI());
    }

    @ExceptionHandler(DocumentNotFoundException.class)
    public ResponseEntity<ErrorResponse> handleDocumentNotFound(DocumentNotFoundException exception, HttpServletRequest request) {
        return build(HttpStatus.NOT_FOUND, "DOCUMENT_NOT_FOUND", exception.getMessage(), request.getRequestURI());
    }

    @ExceptionHandler(MeetingAccessDeniedException.class)
    public ResponseEntity<ErrorResponse> handleAccessDenied(MeetingAccessDeniedException exception, HttpServletRequest request) {
        return build(HttpStatus.FORBIDDEN, "MEETING_ACCESS_DENIED", exception.getMessage(), request.getRequestURI());
    }

    @ExceptionHandler(BusinessValidationException.class)
    public ResponseEntity<ErrorResponse> handleBusiness(BusinessValidationException exception, HttpServletRequest request) {
        return build(HttpStatus.BAD_REQUEST, "BUSINESS_VALIDATION_ERROR", exception.getMessage(), request.getRequestURI());
    }

    @ExceptionHandler(LiveKitOperationException.class)
    public ResponseEntity<ErrorResponse> handleLiveKit(LiveKitOperationException exception, HttpServletRequest request) {
        return build(HttpStatus.BAD_GATEWAY, "LIVEKIT_ERROR", exception.getMessage(), request.getRequestURI());
    }

    @ExceptionHandler(AiServiceException.class)
    public ResponseEntity<ErrorResponse> handleAi(AiServiceException exception, HttpServletRequest request) {
        return build(HttpStatus.BAD_GATEWAY, "AI_SERVICE_ERROR", exception.getMessage(), request.getRequestURI());
    }

    @ExceptionHandler(Exception.class)
    public ResponseEntity<ErrorResponse> handleGeneric(Exception exception, HttpServletRequest request) {
        return build(HttpStatus.INTERNAL_SERVER_ERROR, "INTERNAL_SERVER_ERROR", exception.getMessage(), request.getRequestURI());
    }

    @ExceptionHandler(DataIntegrityViolationException.class)
    public ResponseEntity<ErrorResponse> handleDataIntegrity(DataIntegrityViolationException exception, HttpServletRequest request) {
        String message = "Không thể xử lý dữ liệu yêu cầu.";
        String code = "DATA_INTEGRITY_VIOLATION";
        HttpStatus status = HttpStatus.CONFLICT;

        if (exception.getMostSpecificCause() != null) {
            String details = exception.getMostSpecificCause().getMessage();
            if (details != null && details.contains("uk_meeting_user")) {
                message = "Người tham gia này đã tồn tại trong cuộc họp.";
                code = "PARTICIPANT_ALREADY_EXISTS";
            }
        }

        return build(status, code, message, request.getRequestURI());
    }

    private ResponseEntity<ErrorResponse> build(HttpStatus status, String code, String message, String path) {
        return ResponseEntity.status(status).body(new ErrorResponse(
            LocalDateTime.now(),
            status.value(),
            status.getReasonPhrase(),
            code,
            message,
            path
        ));
    }
}
