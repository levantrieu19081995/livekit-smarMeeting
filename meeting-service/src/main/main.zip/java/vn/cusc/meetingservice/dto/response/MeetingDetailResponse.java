package vn.cusc.meetingservice.dto.response;

import java.time.LocalDateTime;
import java.util.List;
import vn.cusc.meetingservice.model.enums.MeetingAccessType;
import vn.cusc.meetingservice.model.enums.MeetingStatus;

public record MeetingDetailResponse(
    Long id,
    String meetingCode,
    String title,
    String description,
    String roomName,
    String roomSid,
    String meetingUrl,
    LocalDateTime startTime,
    LocalDateTime endTime,
    MeetingStatus status,
    MeetingAccessType accessType,
    List<MeetingParticipantResponse> participants
) {
}
