package vn.cusc.meetingservice.mapper;

import org.springframework.stereotype.Component;
import vn.cusc.meetingservice.dto.response.MeetingDocumentResponse;
import vn.cusc.meetingservice.entity.MeetingDocumentEntity;

@Component
public class MeetingDocumentMapper {

    public MeetingDocumentResponse toResponse(MeetingDocumentEntity entity) {
        return new MeetingDocumentResponse(
            entity.getId(),
            entity.getOriginalFileName(),
            entity.getStoredFileName(),
            entity.getContentType(),
            entity.getFileSize(),
            entity.getStoragePath(),
            entity.getCreatedAt()
        );
    }
}
