package vn.cusc.meetingservice.repository;

import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import vn.cusc.meetingservice.entity.MeetingEntity;

public interface MeetingRepository extends JpaRepository<MeetingEntity, Long>, JpaSpecificationExecutor<MeetingEntity> {
    Optional<MeetingEntity> findByMeetingCode(String meetingCode);
    Optional<MeetingEntity> findByRoomName(String roomName);
    boolean existsByMeetingCode(String meetingCode);
    boolean existsByRoomName(String roomName);
}
