package vn.cusc.meetingservice.dto.response;

import java.time.LocalDateTime;

public record MeetingDocumentResponse(
    Long id,
    String originalFileName,
    String storedFileName,
    String contentType,
    Long fileSize,
    String storagePath,
    LocalDateTime createdAt
) {
}
