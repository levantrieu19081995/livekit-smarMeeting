package vn.cusc.meetingservice.dto.ai.response;

public record AiServiceSessionResponse(
    String sessionId,
    String status,
    String message
) {
}
