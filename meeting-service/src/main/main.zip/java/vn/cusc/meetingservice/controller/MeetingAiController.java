package vn.cusc.meetingservice.controller;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import vn.cusc.meetingservice.dto.response.AiSessionResponse;
import vn.cusc.meetingservice.service.MeetingAiOrchestrationService;

@RestController
@RequestMapping("/api/meetings/{meetingId}/ai")
@Tag(name = "AI")
public class MeetingAiController {

    private final MeetingAiOrchestrationService aiOrchestrationService;

    public MeetingAiController(MeetingAiOrchestrationService aiOrchestrationService) {
        this.aiOrchestrationService = aiOrchestrationService;
    }

    @PostMapping("/start")
    @Operation(summary = "Start AI session")
    public AiSessionResponse start(@PathVariable Long meetingId) {
        return aiOrchestrationService.startAi(meetingId);
    }

    @PostMapping("/stop")
    @Operation(summary = "Stop AI session")
    public AiSessionResponse stop(@PathVariable Long meetingId) {
        return aiOrchestrationService.stopAi(meetingId);
    }

    @GetMapping("/status")
    @Operation(summary = "Get AI session status")
    public AiSessionResponse status(@PathVariable Long meetingId) {
        return aiOrchestrationService.getAiStatus(meetingId);
    }
}
