package vn.cusc.meetingservice.dto.request;

import jakarta.validation.constraints.NotBlank;

public record CreateLiveKitRoomRequest(
    @NotBlank(message = "roomName is required") String roomName
) {
}
