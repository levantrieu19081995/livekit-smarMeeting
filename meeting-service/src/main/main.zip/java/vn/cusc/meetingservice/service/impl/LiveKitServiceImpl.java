package vn.cusc.meetingservice.service.impl;

import io.livekit.server.AccessToken;
import io.livekit.server.CanPublish;
import io.livekit.server.CanPublishData;
import io.livekit.server.CanSubscribe;
import io.livekit.server.RoomJoin;
import io.livekit.server.RoomName;
import io.livekit.server.RoomServiceClient;
import java.util.List;
import java.util.Optional;
import org.springframework.stereotype.Service;
import retrofit2.Response;
import livekit.LivekitModels;
import vn.cusc.meetingservice.config.LiveKitProperties;
import vn.cusc.meetingservice.dto.response.LiveKitRoomResponse;
import vn.cusc.meetingservice.exception.LiveKitOperationException;
import vn.cusc.meetingservice.service.LiveKitService;

@Service
public class LiveKitServiceImpl implements LiveKitService {

    private final LiveKitProperties liveKitProperties;
    private final RoomServiceClient roomServiceClient;

    public LiveKitServiceImpl(LiveKitProperties liveKitProperties) {
        this.liveKitProperties = liveKitProperties;
        this.roomServiceClient = RoomServiceClient.createClient(
            liveKitProperties.getUrl(),
            liveKitProperties.getApiKey(),
            liveKitProperties.getApiSecret()
        );
    }

    @Override
    public LiveKitRoomResponse createRoom(String roomName) {
        try {
            Response<LivekitModels.Room> response = roomServiceClient.createRoom(
                roomName,
                liveKitProperties.getEmptyTimeout(),
                liveKitProperties.getDepartureTimeout()
            ).execute();
            LivekitModels.Room room = requireBody(response, "Khong nhan duoc room sau khi tao");
            return toResponse(room);
        } catch (Exception exception) {
            throw new LiveKitOperationException("Khong the tao LiveKit room " + roomName, exception);
        }
    }

    @Override
    public List<LiveKitRoomResponse> listRooms() {
        try {
            Response<List<LivekitModels.Room>> response = roomServiceClient.listRooms().execute();
            return requireBody(response, "Khong nhan duoc danh sach room").stream().map(this::toResponse).toList();
        } catch (Exception exception) {
            throw new LiveKitOperationException("Khong the lay danh sach LiveKit rooms", exception);
        }
    }

    @Override
    public Optional<LiveKitRoomResponse> getRoom(String roomName) {
        return listRooms().stream().filter(room -> room.roomName().equals(roomName)).findFirst();
    }

    @Override
    public void deleteRoom(String roomName) {
        try {
            roomServiceClient.deleteRoom(roomName).execute();
        } catch (Exception exception) {
            throw new LiveKitOperationException("Khong the xoa LiveKit room " + roomName, exception);
        }
    }

    @Override
    public LiveKitRoomResponse ensureRoomExists(String roomName) {
        return getRoom(roomName).orElseGet(() -> createRoom(roomName));
    }

    @Override
    public String generateJoinToken(String roomName, String identity, String participantName, boolean canPublish, boolean canSubscribe) {
        try {
            AccessToken accessToken = new AccessToken(liveKitProperties.getApiKey(), liveKitProperties.getApiSecret());
            accessToken.setIdentity(identity);
            accessToken.setName(participantName);
            accessToken.addGrants(
                new RoomJoin(true),
                new RoomName(roomName),
                new CanPublish(canPublish),
                new CanSubscribe(canSubscribe),
                new CanPublishData(true)
            );
            return accessToken.toJwt();
        } catch (Exception exception) {
            throw new LiveKitOperationException("Khong the tao token join cho room " + roomName, exception);
        }
    }

    private LiveKitRoomResponse toResponse(LivekitModels.Room room) {
        return new LiveKitRoomResponse(
            room.getName(),
            room.getSid(),
            room.getNumParticipants(),
            room.getCreationTime()
        );
    }

    private <T> T requireBody(Response<T> response, String message) {
        if (!response.isSuccessful() || response.body() == null) {
            throw new LiveKitOperationException(message + " (HTTP " + response.code() + ")");
        }
        return response.body();
    }
}
