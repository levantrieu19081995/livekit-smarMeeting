package vn.cusc.meetingservice.dto.ai.callback;

import com.fasterxml.jackson.databind.JsonNode;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import java.util.List;
import vn.cusc.meetingservice.model.enums.AiSessionStatus;

public record AiMeetingResultRequest(
    @NotBlank String aiSessionId,
    @NotBlank String roomName,
    @NotNull AiSessionStatus status,
    String rawTranscript,
    @Valid List<AiTranscriptSegmentRequest> segments,
    @NotNull JsonNode minutes
) {
}
