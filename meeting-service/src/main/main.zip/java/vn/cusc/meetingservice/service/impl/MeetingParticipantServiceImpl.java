package vn.cusc.meetingservice.service.impl;

import java.util.List;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import vn.cusc.meetingservice.dto.request.AddMeetingParticipantRequest;
import vn.cusc.meetingservice.dto.request.UpdateMeetingParticipantRequest;
import vn.cusc.meetingservice.dto.request.UpdateMeetingParticipantRoleRequest;
import vn.cusc.meetingservice.dto.response.MeetingParticipantResponse;
import vn.cusc.meetingservice.entity.MeetingEntity;
import vn.cusc.meetingservice.entity.MeetingParticipantEntity;
import vn.cusc.meetingservice.exception.MeetingNotFoundException;
import vn.cusc.meetingservice.exception.ParticipantAlreadyExistsException;
import vn.cusc.meetingservice.exception.ParticipantNotFoundException;
import vn.cusc.meetingservice.mapper.MeetingParticipantMapper;
import vn.cusc.meetingservice.model.enums.ParticipantStatus;
import vn.cusc.meetingservice.repository.MeetingParticipantRepository;
import vn.cusc.meetingservice.repository.MeetingRepository;
import vn.cusc.meetingservice.service.MeetingParticipantService;

@Service
public class MeetingParticipantServiceImpl implements MeetingParticipantService {

    private final MeetingRepository meetingRepository;
    private final MeetingParticipantRepository participantRepository;
    private final MeetingParticipantMapper participantMapper;

    public MeetingParticipantServiceImpl(MeetingRepository meetingRepository, MeetingParticipantRepository participantRepository,
                                         MeetingParticipantMapper participantMapper) {
        this.meetingRepository = meetingRepository;
        this.participantRepository = participantRepository;
        this.participantMapper = participantMapper;
    }

    @Override
    @Transactional(readOnly = true)
    public List<MeetingParticipantResponse> getParticipants(Long meetingId) {
        validateMeetingExists(meetingId);
        return participantRepository.findByMeetingId(meetingId).stream().map(participantMapper::toResponse).toList();
    }

    @Override
    @Transactional
    public MeetingParticipantResponse addParticipant(Long meetingId, AddMeetingParticipantRequest request) {
        MeetingEntity meeting = findMeeting(meetingId);
        if (participantRepository.existsByMeetingIdAndUserId(meetingId, request.userId())) {
            throw new ParticipantAlreadyExistsException(request.userId());
        }
        MeetingParticipantEntity participant = new MeetingParticipantEntity();
        participant.setMeeting(meeting);
        participant.setUserId(request.userId());
        participant.setFullName(request.fullName());
        participant.setEmail(request.email());
        participant.setRole(request.role());
        participant.setStatus(ParticipantStatus.INVITED);
        return participantMapper.toResponse(participantRepository.save(participant));
    }

    @Override
    @Transactional
    public MeetingParticipantResponse updateParticipant(Long meetingId, String userId, UpdateMeetingParticipantRequest request) {
        MeetingParticipantEntity participant = findParticipant(meetingId, userId);
        participant.setFullName(request.fullName());
        participant.setEmail(request.email());
        participant.setRole(request.role());
        return participantMapper.toResponse(participantRepository.save(participant));
    }

    @Override
    @Transactional
    public MeetingParticipantResponse updateParticipantRole(Long meetingId, String userId, UpdateMeetingParticipantRoleRequest request) {
        MeetingParticipantEntity participant = findParticipant(meetingId, userId);
        participant.setRole(request.role());
        return participantMapper.toResponse(participantRepository.save(participant));
    }

    @Override
    @Transactional
    public void deleteParticipant(Long meetingId, String userId) {
        MeetingParticipantEntity participant = findParticipant(meetingId, userId);
        participant.setStatus(ParticipantStatus.REMOVED);
        participantRepository.save(participant);
    }

    private MeetingEntity findMeeting(Long meetingId) {
        return meetingRepository.findById(meetingId).orElseThrow(() -> new MeetingNotFoundException(meetingId));
    }

    private void validateMeetingExists(Long meetingId) {
        if (!meetingRepository.existsById(meetingId)) {
            throw new MeetingNotFoundException(meetingId);
        }
    }

    private MeetingParticipantEntity findParticipant(Long meetingId, String userId) {
        return participantRepository.findByMeetingIdAndUserId(meetingId, userId)
            .orElseThrow(() -> new ParticipantNotFoundException(meetingId, userId));
    }
}
