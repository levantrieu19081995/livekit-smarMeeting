package vn.cusc.meetingservice.dto.ai.response;

public record AiServiceStatusResponse(
    String status,
    String message
) {
}
