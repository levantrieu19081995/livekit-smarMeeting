package vn.cusc.meetingservice.dto.response;

public record JoinMeetingResponse(
    String roomName,
    String roomSid,
    String serverUrl,
    String token,
    MeetingParticipantResponse participant
) {
}
