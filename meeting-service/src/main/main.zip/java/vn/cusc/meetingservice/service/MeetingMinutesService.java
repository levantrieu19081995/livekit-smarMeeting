package vn.cusc.meetingservice.service;

import java.util.List;
import vn.cusc.meetingservice.dto.request.SaveMeetingMinutesRequest;
import vn.cusc.meetingservice.dto.response.MeetingMinutesResponse;

public interface MeetingMinutesService {
    List<MeetingMinutesResponse> getMinutes(Long meetingId);
    MeetingMinutesResponse saveMinutes(Long meetingId, SaveMeetingMinutesRequest request);
}
