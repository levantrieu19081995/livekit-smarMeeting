package vn.cusc.meetingservice.dto.ai.request;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

public record StartAiMeetingRequest(
    @NotNull Long meetingId,
    @NotBlank String roomName,
    @NotBlank String livekitUrl,
    @NotBlank String agentIdentity
) {
}
