package vn.cusc.meetingservice.service.impl;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import vn.cusc.meetingservice.config.StorageProperties;
import vn.cusc.meetingservice.service.FileStorageService;
import vn.cusc.meetingservice.util.FileNameUtils;

@Service
public class LocalFileStorageServiceImpl implements FileStorageService {

    private final StorageProperties storageProperties;
    private final FileNameUtils fileNameUtils;

    public LocalFileStorageServiceImpl(StorageProperties storageProperties, FileNameUtils fileNameUtils) {
        this.storageProperties = storageProperties;
        this.fileNameUtils = fileNameUtils;
    }

    @Override
    public StoredFile storeMeetingFile(Long meetingId, MultipartFile file) throws IOException {
        String storedFileName = fileNameUtils.buildStoredFileName(file.getOriginalFilename());
        Path directory = Paths.get(storageProperties.getUploadDir(), "meetings", String.valueOf(meetingId));
        Files.createDirectories(directory);
        Path target = directory.resolve(storedFileName);
        try (InputStream inputStream = file.getInputStream()) {
            Files.copy(inputStream, target);
        }
        return new StoredFile(
            file.getOriginalFilename(),
            storedFileName,
            file.getContentType() == null ? "application/octet-stream" : file.getContentType(),
            file.getSize(),
            target.toString()
        );
    }

    @Override
    public void delete(Path path) throws IOException {
        Files.deleteIfExists(path);
    }
}
