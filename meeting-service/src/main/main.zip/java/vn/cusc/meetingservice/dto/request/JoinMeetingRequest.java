package vn.cusc.meetingservice.dto.request;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import vn.cusc.meetingservice.model.enums.ParticipantJoinType;

public record JoinMeetingRequest(
    @NotNull(message = "participantType is required")
    ParticipantJoinType participantType,

    @Size(max = 100, message = "userId must not exceed 100 characters")
    String userId,

    @NotBlank(message = "displayName is required")
    @Size(max = 255, message = "displayName must not exceed 255 characters")
    String displayName,

    @Email(message = "email is invalid")
    @Size(max = 255, message = "email must not exceed 255 characters")
    String email
) {
}
