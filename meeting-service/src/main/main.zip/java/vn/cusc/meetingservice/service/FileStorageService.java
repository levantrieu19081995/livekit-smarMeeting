package vn.cusc.meetingservice.service;

import java.io.IOException;
import java.nio.file.Path;
import org.springframework.web.multipart.MultipartFile;

public interface FileStorageService {
    StoredFile storeMeetingFile(Long meetingId, MultipartFile file) throws IOException;
    void delete(Path path) throws IOException;

    record StoredFile(String originalFileName, String storedFileName, String contentType, long size, String storagePath) {
    }
}
