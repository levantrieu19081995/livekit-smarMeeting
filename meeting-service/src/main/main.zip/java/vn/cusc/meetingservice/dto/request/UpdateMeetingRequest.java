package vn.cusc.meetingservice.dto.request;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import java.time.LocalDateTime;
import vn.cusc.meetingservice.model.enums.MeetingAccessType;
import vn.cusc.meetingservice.model.enums.MeetingStatus;

public record UpdateMeetingRequest(
    @NotBlank(message = "title is required") String title,
    String description,
    @NotNull(message = "startTime is required") LocalDateTime startTime,
    @NotNull(message = "endTime is required") LocalDateTime endTime,
    @NotNull(message = "accessType is required") MeetingAccessType accessType,
    MeetingStatus status
) {
}
