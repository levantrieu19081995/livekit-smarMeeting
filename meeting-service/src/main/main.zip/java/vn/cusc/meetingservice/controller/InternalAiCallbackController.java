package vn.cusc.meetingservice.controller;

import io.swagger.v3.oas.annotations.Hidden;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import vn.cusc.meetingservice.dto.ai.callback.AiMeetingResultRequest;
import vn.cusc.meetingservice.service.MeetingAiOrchestrationService;

@Hidden
@RestController
@RequestMapping("/internal/api/meetings/{meetingId}/ai-result")
public class InternalAiCallbackController {

    private final MeetingAiOrchestrationService aiOrchestrationService;

    public InternalAiCallbackController(MeetingAiOrchestrationService aiOrchestrationService) {
        this.aiOrchestrationService = aiOrchestrationService;
    }

    @PostMapping
    @ResponseStatus(HttpStatus.ACCEPTED)
    public void receiveResult(@PathVariable Long meetingId,
                              @RequestHeader("X-Internal-Api-Key") String internalApiKey,
                              @Valid @RequestBody AiMeetingResultRequest request) {
        aiOrchestrationService.handleAiResult(meetingId, internalApiKey, request);
    }
}
