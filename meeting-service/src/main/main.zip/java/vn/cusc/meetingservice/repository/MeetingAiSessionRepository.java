package vn.cusc.meetingservice.repository;

import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import vn.cusc.meetingservice.entity.MeetingAiSessionEntity;

public interface MeetingAiSessionRepository extends JpaRepository<MeetingAiSessionEntity, Long> {
    List<MeetingAiSessionEntity> findByMeetingIdOrderByCreatedAtDesc(Long meetingId);
    Optional<MeetingAiSessionEntity> findFirstByMeetingIdOrderByCreatedAtDesc(Long meetingId);
    Optional<MeetingAiSessionEntity> findByExternalSessionId(String externalSessionId);
}
