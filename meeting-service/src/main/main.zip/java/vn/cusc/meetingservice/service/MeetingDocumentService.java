package vn.cusc.meetingservice.service;

import java.util.List;
import org.springframework.web.multipart.MultipartFile;
import vn.cusc.meetingservice.dto.response.MeetingDocumentResponse;

public interface MeetingDocumentService {
    List<MeetingDocumentResponse> getDocuments(Long meetingId);
    MeetingDocumentResponse uploadDocument(Long meetingId, MultipartFile file);
    void deleteDocument(Long meetingId, Long documentId);
}
