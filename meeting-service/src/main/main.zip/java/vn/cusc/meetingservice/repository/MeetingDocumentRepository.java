package vn.cusc.meetingservice.repository;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import vn.cusc.meetingservice.entity.MeetingDocumentEntity;

public interface MeetingDocumentRepository extends JpaRepository<MeetingDocumentEntity, Long> {
    List<MeetingDocumentEntity> findByMeetingId(Long meetingId);
}
