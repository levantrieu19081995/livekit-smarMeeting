package vn.cusc.meetingservice.mapper;

import java.util.List;
import org.springframework.stereotype.Component;
import vn.cusc.meetingservice.config.FrontendProperties;
import vn.cusc.meetingservice.dto.response.MeetingDetailResponse;
import vn.cusc.meetingservice.dto.response.MeetingParticipantResponse;
import vn.cusc.meetingservice.dto.response.MeetingResponse;
import vn.cusc.meetingservice.entity.MeetingEntity;

@Component
public class MeetingMapper {

    private final FrontendProperties frontendProperties;
    private final MeetingParticipantMapper participantMapper;

    public MeetingMapper(FrontendProperties frontendProperties, MeetingParticipantMapper participantMapper) {
        this.frontendProperties = frontendProperties;
        this.participantMapper = participantMapper;
    }

    public MeetingResponse toResponse(MeetingEntity entity) {
        return new MeetingResponse(
            entity.getId(),
            entity.getMeetingCode(),
            entity.getTitle(),
            entity.getDescription(),
            entity.getRoomName(),
            entity.getRoomSid(),
            frontendProperties.getBaseUrl() + "/rooms/" + entity.getRoomName(),
            entity.getStartTime(),
            entity.getEndTime(),
            entity.getStatus(),
            entity.getAccessType()
        );
    }

    public MeetingDetailResponse toDetailResponse(MeetingEntity entity) {
        List<MeetingParticipantResponse> participants = entity.getParticipants().stream()
            .map(participantMapper::toResponse)
            .toList();
        return new MeetingDetailResponse(
            entity.getId(),
            entity.getMeetingCode(),
            entity.getTitle(),
            entity.getDescription(),
            entity.getRoomName(),
            entity.getRoomSid(),
            frontendProperties.getBaseUrl() + "/rooms/" + entity.getRoomName(),
            entity.getStartTime(),
            entity.getEndTime(),
            entity.getStatus(),
            entity.getAccessType(),
            participants
        );
    }
}
