package vn.cusc.meetingservice.dto.ai.request;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

public record StopAiMeetingRequest(
    @NotNull Long meetingId,
    @NotBlank String externalSessionId
) {
}
