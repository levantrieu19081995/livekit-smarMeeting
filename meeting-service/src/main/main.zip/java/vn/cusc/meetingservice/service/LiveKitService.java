package vn.cusc.meetingservice.service;

import java.util.List;
import java.util.Optional;
import vn.cusc.meetingservice.dto.response.LiveKitRoomResponse;

public interface LiveKitService {
    LiveKitRoomResponse createRoom(String roomName);
    List<LiveKitRoomResponse> listRooms();
    Optional<LiveKitRoomResponse> getRoom(String roomName);
    void deleteRoom(String roomName);
    LiveKitRoomResponse ensureRoomExists(String roomName);
    String generateJoinToken(String roomName, String identity, String participantName, boolean canPublish, boolean canSubscribe);
}
