package vn.cusc.meetingservice.service.impl;

import java.io.IOException;
import java.nio.file.Path;
import java.util.List;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;
import vn.cusc.meetingservice.dto.response.MeetingDocumentResponse;
import vn.cusc.meetingservice.entity.MeetingDocumentEntity;
import vn.cusc.meetingservice.entity.MeetingEntity;
import vn.cusc.meetingservice.exception.DocumentNotFoundException;
import vn.cusc.meetingservice.exception.MeetingNotFoundException;
import vn.cusc.meetingservice.mapper.MeetingDocumentMapper;
import vn.cusc.meetingservice.repository.MeetingDocumentRepository;
import vn.cusc.meetingservice.repository.MeetingRepository;
import vn.cusc.meetingservice.service.FileStorageService;
import vn.cusc.meetingservice.service.MeetingDocumentService;

@Service
public class MeetingDocumentServiceImpl implements MeetingDocumentService {

    private final MeetingRepository meetingRepository;
    private final MeetingDocumentRepository documentRepository;
    private final FileStorageService fileStorageService;
    private final MeetingDocumentMapper documentMapper;

    public MeetingDocumentServiceImpl(MeetingRepository meetingRepository, MeetingDocumentRepository documentRepository,
                                      FileStorageService fileStorageService, MeetingDocumentMapper documentMapper) {
        this.meetingRepository = meetingRepository;
        this.documentRepository = documentRepository;
        this.fileStorageService = fileStorageService;
        this.documentMapper = documentMapper;
    }

    @Override
    @Transactional(readOnly = true)
    public List<MeetingDocumentResponse> getDocuments(Long meetingId) {
        ensureMeetingExists(meetingId);
        return documentRepository.findByMeetingId(meetingId).stream().map(documentMapper::toResponse).toList();
    }

    @Override
    @Transactional
    public MeetingDocumentResponse uploadDocument(Long meetingId, MultipartFile file) {
        MeetingEntity meeting = meetingRepository.findById(meetingId).orElseThrow(() -> new MeetingNotFoundException(meetingId));
        try {
            FileStorageService.StoredFile storedFile = fileStorageService.storeMeetingFile(meetingId, file);
            MeetingDocumentEntity entity = new MeetingDocumentEntity();
            entity.setMeeting(meeting);
            entity.setOriginalFileName(storedFile.originalFileName());
            entity.setStoredFileName(storedFile.storedFileName());
            entity.setContentType(storedFile.contentType());
            entity.setFileSize(storedFile.size());
            entity.setStoragePath(storedFile.storagePath());
            return documentMapper.toResponse(documentRepository.save(entity));
        } catch (IOException exception) {
            throw new IllegalStateException("Khong the luu file tai lieu", exception);
        }
    }

    @Override
    @Transactional
    public void deleteDocument(Long meetingId, Long documentId) {
        ensureMeetingExists(meetingId);
        MeetingDocumentEntity document = documentRepository.findById(documentId)
            .filter(item -> item.getMeeting().getId().equals(meetingId))
            .orElseThrow(() -> new DocumentNotFoundException(documentId));
        try {
            fileStorageService.delete(Path.of(document.getStoragePath()));
        } catch (IOException ignored) {
        }
        documentRepository.delete(document);
    }

    private void ensureMeetingExists(Long meetingId) {
        if (!meetingRepository.existsById(meetingId)) {
            throw new MeetingNotFoundException(meetingId);
        }
    }
}
