package vn.cusc.meetingservice.service;

import vn.cusc.meetingservice.dto.ai.callback.AiMeetingResultRequest;
import vn.cusc.meetingservice.dto.response.AiSessionResponse;

public interface MeetingAiOrchestrationService {
    AiSessionResponse startAi(Long meetingId);
    AiSessionResponse stopAi(Long meetingId);
    AiSessionResponse getAiStatus(Long meetingId);
    void handleAiResult(Long meetingId, String internalApiKey, AiMeetingResultRequest request);
}
