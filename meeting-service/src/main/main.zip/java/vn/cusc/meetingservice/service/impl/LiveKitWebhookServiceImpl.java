package vn.cusc.meetingservice.service.impl;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.time.LocalDateTime;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import vn.cusc.meetingservice.repository.MeetingParticipantRepository;
import vn.cusc.meetingservice.service.LiveKitWebhookService;

@Service
public class LiveKitWebhookServiceImpl implements LiveKitWebhookService {

    private final ObjectMapper objectMapper;
    private final MeetingParticipantRepository participantRepository;

    public LiveKitWebhookServiceImpl(ObjectMapper objectMapper, MeetingParticipantRepository participantRepository) {
        this.objectMapper = objectMapper;
        this.participantRepository = participantRepository;
    }

    @Override
    @Transactional
    public void handleWebhook(String authorization, String payload) {
        try {
            JsonNode root = objectMapper.readTree(payload);
            String event = root.path("event").asText();
            String identity = root.path("participant").path("identity").asText(null);
            Long meetingId = root.path("meetingId").isNumber() ? root.path("meetingId").asLong() : null;
            if (meetingId == null || identity == null) {
                return;
            }
            participantRepository.findByMeetingIdAndUserId(meetingId, identity).ifPresent(participant -> {
                if ("participant_joined".equals(event)) {
                    participant.setJoinedAt(LocalDateTime.now());
                }
                if ("participant_left".equals(event)) {
                    participant.setLeftAt(LocalDateTime.now());
                }
                participantRepository.save(participant);
            });
        } catch (Exception ignored) {
        }
    }
}
