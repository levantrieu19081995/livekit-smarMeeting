package vn.cusc.meetingservice.service.impl;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.time.LocalDateTime;
import java.util.List;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import vn.cusc.meetingservice.dto.request.SaveMeetingMinutesRequest;
import vn.cusc.meetingservice.dto.response.MeetingMinutesResponse;
import vn.cusc.meetingservice.entity.MeetingEntity;
import vn.cusc.meetingservice.entity.MeetingMinutesEntity;
import vn.cusc.meetingservice.exception.MeetingNotFoundException;
import vn.cusc.meetingservice.mapper.MeetingMinutesMapper;
import vn.cusc.meetingservice.repository.MeetingMinutesRepository;
import vn.cusc.meetingservice.repository.MeetingRepository;
import vn.cusc.meetingservice.service.MeetingMinutesService;

@Service
public class MeetingMinutesServiceImpl implements MeetingMinutesService {

    private final MeetingRepository meetingRepository;
    private final MeetingMinutesRepository minutesRepository;
    private final MeetingMinutesMapper minutesMapper;
    private final ObjectMapper objectMapper;

    public MeetingMinutesServiceImpl(MeetingRepository meetingRepository, MeetingMinutesRepository minutesRepository,
                                     MeetingMinutesMapper minutesMapper, ObjectMapper objectMapper) {
        this.meetingRepository = meetingRepository;
        this.minutesRepository = minutesRepository;
        this.minutesMapper = minutesMapper;
        this.objectMapper = objectMapper;
    }

    @Override
    @Transactional(readOnly = true)
    public List<MeetingMinutesResponse> getMinutes(Long meetingId) {
        ensureMeetingExists(meetingId);
        return minutesRepository.findByMeetingIdOrderByVersionDesc(meetingId).stream().map(minutesMapper::toResponse).toList();
    }

    @Override
    @Transactional
    public MeetingMinutesResponse saveMinutes(Long meetingId, SaveMeetingMinutesRequest request) {
        MeetingEntity meeting = meetingRepository.findById(meetingId).orElseThrow(() -> new MeetingNotFoundException(meetingId));
        int nextVersion = minutesRepository.findFirstByMeetingIdOrderByVersionDesc(meetingId)
            .map(item -> item.getVersion() + 1)
            .orElse(1);
        try {
            MeetingMinutesEntity entity = new MeetingMinutesEntity();
            entity.setMeeting(meeting);
            entity.setVersion(nextVersion);
            entity.setRawTranscript(request.rawTranscript());
            entity.setMinutesJson(objectMapper.writeValueAsString(request.minutes()));
            entity.setGeneratedAt(LocalDateTime.now());
            return minutesMapper.toResponse(minutesRepository.save(entity));
        } catch (Exception exception) {
            throw new IllegalStateException("Khong the luu bien ban", exception);
        }
    }

    private void ensureMeetingExists(Long meetingId) {
        if (!meetingRepository.existsById(meetingId)) {
            throw new MeetingNotFoundException(meetingId);
        }
    }
}
