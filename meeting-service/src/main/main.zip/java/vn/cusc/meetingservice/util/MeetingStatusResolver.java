package vn.cusc.meetingservice.util;

import java.time.LocalDateTime;
import org.springframework.stereotype.Component;
import vn.cusc.meetingservice.entity.MeetingEntity;
import vn.cusc.meetingservice.model.enums.MeetingStatus;

@Component
public class MeetingStatusResolver {

    public MeetingStatus resolve(MeetingEntity meeting) {
        if (meeting.getStatus() == MeetingStatus.CANCELLED) {
            return MeetingStatus.CANCELLED;
        }
        LocalDateTime now = LocalDateTime.now();
        if (now.isBefore(meeting.getStartTime())) {
            return MeetingStatus.UPCOMING;
        }
        if (!now.isAfter(meeting.getEndTime())) {
            return MeetingStatus.IN_PROGRESS;
        }
        return MeetingStatus.COMPLETED;
    }
}
