package vn.cusc.meetingservice.controller;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import java.util.List;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import vn.cusc.meetingservice.dto.request.SaveMeetingMinutesRequest;
import vn.cusc.meetingservice.dto.response.MeetingMinutesResponse;
import vn.cusc.meetingservice.service.MeetingMinutesService;

@RestController
@RequestMapping("/api/meetings/{meetingId}/minutes")
@Tag(name = "Minutes")
public class MeetingMinutesController {

    private final MeetingMinutesService meetingMinutesService;

    public MeetingMinutesController(MeetingMinutesService meetingMinutesService) {
        this.meetingMinutesService = meetingMinutesService;
    }

    @GetMapping
    @Operation(summary = "Get minutes versions")
    public List<MeetingMinutesResponse> getMinutes(@PathVariable Long meetingId) {
        return meetingMinutesService.getMinutes(meetingId);
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    @Operation(summary = "Save minutes")
    public MeetingMinutesResponse saveMinutes(@PathVariable Long meetingId, @Valid @RequestBody SaveMeetingMinutesRequest request) {
        return meetingMinutesService.saveMinutes(meetingId, request);
    }
}
