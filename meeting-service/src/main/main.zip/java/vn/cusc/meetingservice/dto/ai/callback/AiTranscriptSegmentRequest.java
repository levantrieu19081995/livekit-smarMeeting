package vn.cusc.meetingservice.dto.ai.callback;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import vn.cusc.meetingservice.model.enums.MeetingRole;

public record AiTranscriptSegmentRequest(
    @NotBlank String participantIdentity,
    @NotBlank String speakerName,
    @NotNull MeetingRole role,
    @NotNull Long startMs,
    @NotNull Long endMs,
    @NotBlank String text
) {
}
