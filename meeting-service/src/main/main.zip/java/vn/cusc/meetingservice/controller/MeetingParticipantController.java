package vn.cusc.meetingservice.controller;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import java.util.List;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import vn.cusc.meetingservice.dto.request.AddMeetingParticipantRequest;
import vn.cusc.meetingservice.dto.request.UpdateMeetingParticipantRequest;
import vn.cusc.meetingservice.dto.request.UpdateMeetingParticipantRoleRequest;
import vn.cusc.meetingservice.dto.response.MeetingParticipantResponse;
import vn.cusc.meetingservice.service.MeetingParticipantService;

@RestController
@RequestMapping("/api/meetings/{meetingId}/participants")
@Tag(name = "Participants")
public class MeetingParticipantController {

    private final MeetingParticipantService participantService;

    public MeetingParticipantController(MeetingParticipantService participantService) {
        this.participantService = participantService;
    }

    @GetMapping
    @Operation(summary = "Get participants")
    public List<MeetingParticipantResponse> getParticipants(@PathVariable Long meetingId) {
        return participantService.getParticipants(meetingId);
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    @Operation(summary = "Add participant")
    public MeetingParticipantResponse addParticipant(@PathVariable Long meetingId,
                                                     @Valid @RequestBody AddMeetingParticipantRequest request) {
        return participantService.addParticipant(meetingId, request);
    }

    @PutMapping("/{userId}")
    @Operation(summary = "Update participant")
    public MeetingParticipantResponse updateParticipant(@PathVariable Long meetingId, @PathVariable String userId,
                                                        @Valid @RequestBody UpdateMeetingParticipantRequest request) {
        return participantService.updateParticipant(meetingId, userId, request);
    }

    @PutMapping("/{userId}/role")
    @Operation(summary = "Update participant role")
    public MeetingParticipantResponse updateParticipantRole(@PathVariable Long meetingId, @PathVariable String userId,
                                                            @Valid @RequestBody UpdateMeetingParticipantRoleRequest request) {
        return participantService.updateParticipantRole(meetingId, userId, request);
    }

    @DeleteMapping("/{userId}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    @Operation(summary = "Remove participant")
    public void deleteParticipant(@PathVariable Long meetingId, @PathVariable String userId) {
        participantService.deleteParticipant(meetingId, userId);
    }
}
