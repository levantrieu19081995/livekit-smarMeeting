package vn.cusc.meetingservice.controller;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import java.util.List;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import vn.cusc.meetingservice.dto.request.CreateLiveKitRoomRequest;
import vn.cusc.meetingservice.dto.response.LiveKitRoomResponse;
import vn.cusc.meetingservice.service.LiveKitService;

@RestController
@RequestMapping("/api/livekit/rooms")
@Tag(name = "LiveKit")
public class LiveKitRoomController {

    private final LiveKitService liveKitService;

    public LiveKitRoomController(LiveKitService liveKitService) {
        this.liveKitService = liveKitService;
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    @Operation(summary = "Create LiveKit room")
    public LiveKitRoomResponse createRoom(@Valid @RequestBody CreateLiveKitRoomRequest request) {
        return liveKitService.createRoom(request.roomName());
    }

    @GetMapping
    @Operation(summary = "List LiveKit rooms")
    public List<LiveKitRoomResponse> listRooms() {
        return liveKitService.listRooms();
    }

    @GetMapping("/{roomName}")
    @Operation(summary = "Get LiveKit room")
    public LiveKitRoomResponse getRoom(@PathVariable String roomName) {
        return liveKitService.getRoom(roomName).orElse(null);
    }

    @DeleteMapping("/{roomName}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    @Operation(summary = "Delete LiveKit room")
    public void deleteRoom(@PathVariable String roomName) {
        liveKitService.deleteRoom(roomName);
    }
}
