package vn.cusc.meetingservice.client.ai;

import org.springframework.stereotype.Component;
import org.springframework.web.client.RestClient;
import vn.cusc.meetingservice.dto.ai.request.StartAiMeetingRequest;
import vn.cusc.meetingservice.dto.ai.request.StopAiMeetingRequest;
import vn.cusc.meetingservice.dto.ai.response.AiServiceSessionResponse;
import vn.cusc.meetingservice.dto.ai.response.AiServiceStatusResponse;
import vn.cusc.meetingservice.exception.AiServiceException;

@Component
public class MeetingAiClientImpl implements MeetingAiClient {

    private final RestClient aiRestClient;

    public MeetingAiClientImpl(RestClient aiRestClient) {
        this.aiRestClient = aiRestClient;
    }

    @Override
    public AiServiceStatusResponse health() {
        try {
            return aiRestClient.get().uri("/health").retrieve().body(AiServiceStatusResponse.class);
        } catch (Exception exception) {
            throw new AiServiceException("Khong the goi health AI service", exception);
        }
    }

    @Override
    public AiServiceSessionResponse startMeeting(StartAiMeetingRequest request) {
        try {
            return aiRestClient.post()
                .uri("/api/ai/meetings/{meetingId}/start", request.meetingId())
                .body(request)
                .retrieve()
                .body(AiServiceSessionResponse.class);
        } catch (Exception exception) {
            throw new AiServiceException("Khong the start AI meeting", exception);
        }
    }

    @Override
    public AiServiceSessionResponse stopMeeting(Long meetingId, StopAiMeetingRequest request) {
        try {
            return aiRestClient.post()
                .uri("/api/ai/meetings/{meetingId}/stop", meetingId)
                .body(request)
                .retrieve()
                .body(AiServiceSessionResponse.class);
        } catch (Exception exception) {
            throw new AiServiceException("Khong the stop AI meeting", exception);
        }
    }

    @Override
    public AiServiceStatusResponse getMeetingStatus(Long meetingId) {
        try {
            return aiRestClient.get()
                .uri("/api/ai/meetings/{meetingId}/status", meetingId)
                .retrieve()
                .body(AiServiceStatusResponse.class);
        } catch (Exception exception) {
            throw new AiServiceException("Khong the lay AI status", exception);
        }
    }
}
