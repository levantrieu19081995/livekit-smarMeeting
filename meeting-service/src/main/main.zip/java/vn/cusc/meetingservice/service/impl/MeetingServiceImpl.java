package vn.cusc.meetingservice.service.impl;

import jakarta.persistence.criteria.Predicate;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import vn.cusc.meetingservice.dto.request.AddMeetingParticipantRequest;
import vn.cusc.meetingservice.dto.request.CreateMeetingRequest;
import vn.cusc.meetingservice.dto.request.JoinMeetingRequest;
import vn.cusc.meetingservice.dto.request.UpdateMeetingRequest;
import vn.cusc.meetingservice.dto.response.JoinMeetingResponse;
import vn.cusc.meetingservice.dto.response.LiveKitRoomResponse;
import vn.cusc.meetingservice.dto.response.MeetingDetailResponse;
import vn.cusc.meetingservice.dto.response.MeetingParticipantResponse;
import vn.cusc.meetingservice.dto.response.MeetingResponse;
import vn.cusc.meetingservice.dto.response.PageResponse;
import vn.cusc.meetingservice.entity.MeetingEntity;
import vn.cusc.meetingservice.entity.MeetingParticipantEntity;
import vn.cusc.meetingservice.exception.BusinessValidationException;
import vn.cusc.meetingservice.exception.LiveKitOperationException;
import vn.cusc.meetingservice.exception.MeetingAccessDeniedException;
import vn.cusc.meetingservice.exception.MeetingNotFoundException;
import vn.cusc.meetingservice.mapper.MeetingMapper;
import vn.cusc.meetingservice.mapper.MeetingParticipantMapper;
import vn.cusc.meetingservice.model.enums.MeetingAccessType;
import vn.cusc.meetingservice.model.enums.MeetingRole;
import vn.cusc.meetingservice.model.enums.MeetingStatus;
import vn.cusc.meetingservice.model.enums.ParticipantJoinType;
import vn.cusc.meetingservice.model.enums.ParticipantStatus;
import vn.cusc.meetingservice.repository.MeetingRepository;
import vn.cusc.meetingservice.service.LiveKitService;
import vn.cusc.meetingservice.service.MeetingService;
import vn.cusc.meetingservice.config.LiveKitProperties;
import vn.cusc.meetingservice.util.MeetingCodeGenerator;
import vn.cusc.meetingservice.util.MeetingStatusResolver;
import vn.cusc.meetingservice.util.RoomNameGenerator;

@Service
public class MeetingServiceImpl implements MeetingService {

    private final MeetingRepository meetingRepository;
    private final MeetingCodeGenerator meetingCodeGenerator;
    private final RoomNameGenerator roomNameGenerator;
    private final LiveKitService liveKitService;
    private final MeetingMapper meetingMapper;
    private final MeetingParticipantMapper participantMapper;
    private final MeetingStatusResolver statusResolver;
    private final LiveKitProperties liveKitProperties;

    public MeetingServiceImpl(MeetingRepository meetingRepository, MeetingCodeGenerator meetingCodeGenerator,
                              RoomNameGenerator roomNameGenerator, LiveKitService liveKitService,
                              MeetingMapper meetingMapper, MeetingParticipantMapper participantMapper,
                              MeetingStatusResolver statusResolver, LiveKitProperties liveKitProperties) {
        this.meetingRepository = meetingRepository;
        this.meetingCodeGenerator = meetingCodeGenerator;
        this.roomNameGenerator = roomNameGenerator;
        this.liveKitService = liveKitService;
        this.meetingMapper = meetingMapper;
        this.participantMapper = participantMapper;
        this.statusResolver = statusResolver;
        this.liveKitProperties = liveKitProperties;
    }

    @Override
    @Transactional
    public MeetingResponse createMeeting(CreateMeetingRequest request) {
        validateCreateMeetingRequest(request);

        String meetingCode = generateUniqueMeetingCode();
        String roomName = generateUniqueRoomName();
        LiveKitRoomResponse roomResponse = liveKitService.createRoom(roomName);

        try {
            MeetingEntity meeting = new MeetingEntity();
            meeting.setMeetingCode(meetingCode);
            meeting.setTitle(request.title());
            meeting.setDescription(request.description());
            meeting.setRoomName(roomName);
            meeting.setRoomSid(roomResponse.roomSid());
            meeting.setStartTime(request.startTime());
            meeting.setEndTime(request.endTime());
            meeting.setAccessType(request.accessType());
            meeting.setStatus(MeetingStatus.UPCOMING);
            attachParticipants(meeting, request.participants());

            MeetingEntity saved = meetingRepository.save(meeting);
            saved.setStatus(statusResolver.resolve(saved));
            return meetingMapper.toResponse(saved);
        } catch (RuntimeException exception) {
            try {
                liveKitService.deleteRoom(roomName);
            } catch (LiveKitOperationException ignored) {
            }
            throw exception;
        }
    }

    @Override
    @Transactional(readOnly = true)
    public PageResponse<MeetingResponse> getMeetings(String search, MeetingStatus status, MeetingAccessType accessType,
                                                     String fromDate, String toDate, Pageable pageable) {
        Specification<MeetingEntity> specification = (root, query, criteriaBuilder) -> {
            List<Predicate> predicates = new ArrayList<>();
            if (search != null && !search.isBlank()) {
                String likeValue = "%" + search.toLowerCase() + "%";
                predicates.add(criteriaBuilder.or(
                    criteriaBuilder.like(criteriaBuilder.lower(root.get("title")), likeValue),
                    criteriaBuilder.like(criteriaBuilder.lower(root.get("meetingCode")), likeValue),
                    criteriaBuilder.like(criteriaBuilder.lower(root.get("roomName")), likeValue)
                ));
            }
            if (status != null) {
                predicates.add(criteriaBuilder.equal(root.get("status"), status));
            }
            if (accessType != null) {
                predicates.add(criteriaBuilder.equal(root.get("accessType"), accessType));
            }
            if (fromDate != null && !fromDate.isBlank()) {
                predicates.add(criteriaBuilder.greaterThanOrEqualTo(root.get("startTime"), LocalDate.parse(fromDate).atStartOfDay()));
            }
            if (toDate != null && !toDate.isBlank()) {
                predicates.add(criteriaBuilder.lessThanOrEqualTo(root.get("endTime"), LocalDate.parse(toDate).atTime(23, 59, 59)));
            }
            return criteriaBuilder.and(predicates.toArray(Predicate[]::new));
        };

        Page<MeetingResponse> page = meetingRepository.findAll(specification, pageable)
            .map(entity -> {
                entity.setStatus(statusResolver.resolve(entity));
                return meetingMapper.toResponse(entity);
            });

        return new PageResponse<>(
            page.getContent(),
            page.getNumber(),
            page.getSize(),
            page.getTotalElements(),
            page.getTotalPages(),
            page.isFirst(),
            page.isLast()
        );
    }

    @Override
    @Transactional(readOnly = true)
    public MeetingDetailResponse getMeeting(Long meetingId) {
        MeetingEntity meeting = findMeeting(meetingId);
        meeting.setStatus(statusResolver.resolve(meeting));
        return meetingMapper.toDetailResponse(meeting);
    }

    @Override
    @Transactional
    public MeetingResponse updateMeeting(Long meetingId, UpdateMeetingRequest request) {
        validateMeetingUpdateRequest(request);
        MeetingEntity meeting = findMeeting(meetingId);
        meeting.setTitle(request.title());
        meeting.setDescription(request.description());
        meeting.setStartTime(request.startTime());
        meeting.setEndTime(request.endTime());
        meeting.setAccessType(request.accessType());
        if (request.status() != null) {
            meeting.setStatus(request.status());
        } else {
            meeting.setStatus(statusResolver.resolve(meeting));
        }
        return meetingMapper.toResponse(meetingRepository.save(meeting));
    }

    @Override
    @Transactional
    public void deleteMeeting(Long meetingId) {
        MeetingEntity meeting = findMeeting(meetingId);
        meetingRepository.delete(meeting);
        try {
            liveKitService.deleteRoom(meeting.getRoomName());
        } catch (LiveKitOperationException ignored) {
        }
    }

    @Override
    @Transactional
    public JoinMeetingResponse joinMeeting(Long meetingId, JoinMeetingRequest request) {
        MeetingEntity meeting = findMeeting(meetingId);
        meeting.setStatus(statusResolver.resolve(meeting));
        if (
            request.participantType() == ParticipantJoinType.GUEST &&
            meeting.getAccessType() == MeetingAccessType.PRIVATE
        ) {
            throw new MeetingAccessDeniedException(
                "Cuoc hop rieng tu yeu cau nguoi dung dang nhap."
            );
        }

        String resolvedIdentity = resolveParticipantIdentity(request);
        MeetingParticipantEntity participant = meeting.getParticipants().stream()
            .filter(item -> item.getUserId().equals(resolvedIdentity) && item.getStatus() != ParticipantStatus.REMOVED)
            .findFirst()
            .orElse(null);

        if (meeting.getAccessType() == MeetingAccessType.PRIVATE && participant == null) {
            throw new MeetingAccessDeniedException(
                "Ban khong co trong danh sach duoc moi cua cuoc hop rieng tu."
            );
        }

        if (participant == null) {
            participant = new MeetingParticipantEntity();
            participant.setMeeting(meeting);
            participant.setUserId(resolvedIdentity);
            participant.setFullName(request.displayName().trim());
            participant.setEmail(resolveParticipantEmail(request, resolvedIdentity));
            participant.setRole(MeetingRole.GUEST);
            participant.setStatus(ParticipantStatus.INVITED);
            meeting.getParticipants().add(participant);
        } else if (request.participantType() == ParticipantJoinType.GUEST) {
            participant.setFullName(request.displayName().trim());
            participant.setRole(MeetingRole.GUEST);
        }

        LiveKitRoomResponse room = liveKitService.ensureRoomExists(meeting.getRoomName());
        if (!room.roomSid().equals(meeting.getRoomSid())) {
            meeting.setRoomSid(room.roomSid());
        }
        String token = liveKitService.generateJoinToken(
            meeting.getRoomName(),
            participant.getUserId(),
            participant.getFullName(),
            true,
            true
        );
        participant.setStatus(ParticipantStatus.JOINED);
        participant.setJoinedAt(LocalDateTime.now());
        meetingRepository.save(meeting);

        MeetingParticipantResponse participantResponse = participantMapper.toResponse(participant);
        return new JoinMeetingResponse(meeting.getRoomName(), meeting.getRoomSid(), liveKitProperties.getUrl(), token, participantResponse);
    }

    private String resolveParticipantIdentity(JoinMeetingRequest request) {
        if (request.participantType() == ParticipantJoinType.AUTHENTICATED) {
            if (request.userId() == null || request.userId().trim().isEmpty()) {
                throw new BusinessValidationException("userId is required for authenticated participant");
            }

            return request.userId().trim();
        }

        if (request.userId() == null || request.userId().trim().isEmpty()) {
            return "guest-" + UUID.randomUUID();
        }

        String guestId = request.userId().trim();
        if (!isValidGuestIdentity(guestId)) {
            throw new BusinessValidationException("Guest userId must use guest-{UUID} format");
        }

        return guestId;
    }

    private boolean isValidGuestIdentity(String userId) {
        if (userId == null || !userId.startsWith("guest-")) {
            return false;
        }

        try {
            UUID.fromString(userId.substring("guest-".length()));
            return true;
        } catch (IllegalArgumentException exception) {
            return false;
        }
    }

    private String resolveParticipantEmail(JoinMeetingRequest request, String resolvedIdentity) {
        if (request.participantType() == ParticipantJoinType.GUEST) {
            return resolvedIdentity + "@guest.local";
        }

        if (request.email() == null || request.email().trim().isEmpty()) {
            throw new BusinessValidationException("email is required for authenticated participant");
        }

        return request.email().trim();
    }

    private MeetingEntity findMeeting(Long meetingId) {
        return meetingRepository.findById(meetingId).orElseThrow(() -> new MeetingNotFoundException(meetingId));
    }

    private void attachParticipants(MeetingEntity meeting, List<AddMeetingParticipantRequest> participants) {
        if (participants == null) {
            return;
        }
        participants.forEach(request -> {
            MeetingParticipantEntity participant = new MeetingParticipantEntity();
            participant.setMeeting(meeting);
            participant.setUserId(request.userId());
            participant.setFullName(request.fullName());
            participant.setEmail(request.email());
            participant.setRole(request.role());
            participant.setStatus(ParticipantStatus.INVITED);
            meeting.getParticipants().add(participant);
        });
    }

    private void validateCreateMeetingRequest(CreateMeetingRequest request) {
        validateMeetingSchedule(request.startTime(), request.endTime());
        validateCreateParticipants(request.accessType(), request.participants());
    }

    private void validateMeetingUpdateRequest(UpdateMeetingRequest request) {
        validateMeetingSchedule(request.startTime(), request.endTime());
    }

    private void validateMeetingSchedule(LocalDateTime startTime, LocalDateTime endTime) {
        if (endTime == null || startTime == null || !endTime.isAfter(startTime)) {
            throw new BusinessValidationException("endTime phai lon hon startTime");
        }
    }

    private void validateCreateParticipants(MeetingAccessType accessType, List<AddMeetingParticipantRequest> participants) {
        if (accessType == MeetingAccessType.PRIVATE && (participants == null || participants.isEmpty())) {
            throw new BusinessValidationException("Meeting private phai co participant");
        }
        if (participants == null) {
            return;
        }
        Set<String> userIds = new HashSet<>();
        long chairmen = 0;
        long secretaries = 0;
        for (AddMeetingParticipantRequest participant : participants) {
            if (!userIds.add(participant.userId())) {
                throw new BusinessValidationException("Duplicate participant userId: " + participant.userId());
            }
            if (participant.role() == MeetingRole.CHAIRMAN) {
                chairmen++;
            }
            if (participant.role() == MeetingRole.SECRETARY) {
                secretaries++;
            }
        }
        if (chairmen > 1) {
            throw new BusinessValidationException("Chi duoc co toi da 1 chairman");
        }
        if (secretaries > 1) {
            throw new BusinessValidationException("Chi duoc co toi da 1 secretary");
        }
    }

    private String generateUniqueMeetingCode() {
        String meetingCode;
        do {
            meetingCode = meetingCodeGenerator.generate();
        } while (meetingRepository.existsByMeetingCode(meetingCode));
        return meetingCode;
    }

    private String generateUniqueRoomName() {
        String roomName;
        do {
            roomName = roomNameGenerator.generate();
        } while (meetingRepository.existsByRoomName(roomName));
        return roomName;
    }
}
