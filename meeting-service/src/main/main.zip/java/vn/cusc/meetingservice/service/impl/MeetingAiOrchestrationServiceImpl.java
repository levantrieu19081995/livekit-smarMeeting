package vn.cusc.meetingservice.service.impl;

import java.time.LocalDateTime;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import vn.cusc.meetingservice.client.ai.MeetingAiClient;
import vn.cusc.meetingservice.config.AiServiceProperties;
import vn.cusc.meetingservice.config.LiveKitProperties;
import vn.cusc.meetingservice.dto.ai.callback.AiMeetingResultRequest;
import vn.cusc.meetingservice.dto.ai.request.StartAiMeetingRequest;
import vn.cusc.meetingservice.dto.ai.request.StopAiMeetingRequest;
import vn.cusc.meetingservice.dto.ai.response.AiServiceSessionResponse;
import vn.cusc.meetingservice.dto.response.AiSessionResponse;
import vn.cusc.meetingservice.dto.request.SaveMeetingMinutesRequest;
import vn.cusc.meetingservice.entity.MeetingAiSessionEntity;
import vn.cusc.meetingservice.entity.MeetingEntity;
import vn.cusc.meetingservice.exception.AiServiceException;
import vn.cusc.meetingservice.exception.MeetingNotFoundException;
import vn.cusc.meetingservice.model.enums.AiSessionStatus;
import vn.cusc.meetingservice.repository.MeetingAiSessionRepository;
import vn.cusc.meetingservice.repository.MeetingRepository;
import vn.cusc.meetingservice.service.LiveKitService;
import vn.cusc.meetingservice.service.MeetingAiOrchestrationService;
import vn.cusc.meetingservice.service.MeetingMinutesService;

@Service
public class MeetingAiOrchestrationServiceImpl implements MeetingAiOrchestrationService {

    private final MeetingRepository meetingRepository;
    private final MeetingAiSessionRepository sessionRepository;
    private final MeetingAiClient meetingAiClient;
    private final MeetingMinutesService meetingMinutesService;
    private final LiveKitService liveKitService;
    private final LiveKitProperties liveKitProperties;
    private final AiServiceProperties aiServiceProperties;

    public MeetingAiOrchestrationServiceImpl(MeetingRepository meetingRepository, MeetingAiSessionRepository sessionRepository,
                                             MeetingAiClient meetingAiClient, MeetingMinutesService meetingMinutesService,
                                             LiveKitService liveKitService, LiveKitProperties liveKitProperties,
                                             AiServiceProperties aiServiceProperties) {
        this.meetingRepository = meetingRepository;
        this.sessionRepository = sessionRepository;
        this.meetingAiClient = meetingAiClient;
        this.meetingMinutesService = meetingMinutesService;
        this.liveKitService = liveKitService;
        this.liveKitProperties = liveKitProperties;
        this.aiServiceProperties = aiServiceProperties;
    }

    @Override
    @Transactional
    public AiSessionResponse startAi(Long meetingId) {
        MeetingEntity meeting = findMeeting(meetingId);
        liveKitService.ensureRoomExists(meeting.getRoomName());

        MeetingAiSessionEntity session = new MeetingAiSessionEntity();
        session.setMeeting(meeting);
        session.setStatus(AiSessionStatus.STARTING);
        session.setStartedAt(LocalDateTime.now());
        session = sessionRepository.save(session);

        try {
            AiServiceSessionResponse response = meetingAiClient.startMeeting(new StartAiMeetingRequest(
                meetingId,
                meeting.getRoomName(),
                liveKitProperties.getUrl(),
                "AI_MEETING_" + meetingId
            ));
            session.setExternalSessionId(response.sessionId());
            session.setStatus(AiSessionStatus.RUNNING);
            return toResponse(sessionRepository.save(session));
        } catch (RuntimeException exception) {
            session.setStatus(AiSessionStatus.FAILED);
            session.setErrorMessage(exception.getMessage());
            session.setFinishedAt(LocalDateTime.now());
            sessionRepository.save(session);
            throw exception;
        }
    }

    @Override
    @Transactional
    public AiSessionResponse stopAi(Long meetingId) {
        MeetingAiSessionEntity session = findLatestSession(meetingId);
        try {
            meetingAiClient.stopMeeting(meetingId, new StopAiMeetingRequest(meetingId, session.getExternalSessionId()));
            session.setStatus(AiSessionStatus.STOPPED);
            session.setFinishedAt(LocalDateTime.now());
            return toResponse(sessionRepository.save(session));
        } catch (RuntimeException exception) {
            session.setStatus(AiSessionStatus.FAILED);
            session.setErrorMessage(exception.getMessage());
            session.setFinishedAt(LocalDateTime.now());
            sessionRepository.save(session);
            throw exception;
        }
    }

    @Override
    @Transactional(readOnly = true)
    public AiSessionResponse getAiStatus(Long meetingId) {
        MeetingAiSessionEntity session = findLatestSession(meetingId);
        return toResponse(session);
    }

    @Override
    @Transactional
    public void handleAiResult(Long meetingId, String internalApiKey, AiMeetingResultRequest request) {
        if (!aiServiceProperties.getInternalApiKey().equals(internalApiKey)) {
            throw new AiServiceException("Internal API key khong hop le");
        }
        MeetingEntity meeting = findMeeting(meetingId);
        if (!meeting.getRoomName().equals(request.roomName())) {
            throw new AiServiceException("roomName callback khong khop");
        }
        MeetingAiSessionEntity session = sessionRepository.findByExternalSessionId(request.aiSessionId())
            .orElseThrow(() -> new AiServiceException("Khong tim thay AI session"));

        if (request.minutes() != null) {
            meetingMinutesService.saveMinutes(meetingId, new SaveMeetingMinutesRequest(request.rawTranscript(), request.minutes()));
        }
        session.setStatus(request.status());
        session.setFinishedAt(LocalDateTime.now());
        session.setErrorMessage(request.status() == AiSessionStatus.FAILED ? "AI session failed" : null);
        sessionRepository.save(session);
    }

    private MeetingEntity findMeeting(Long meetingId) {
        return meetingRepository.findById(meetingId).orElseThrow(() -> new MeetingNotFoundException(meetingId));
    }

    private MeetingAiSessionEntity findLatestSession(Long meetingId) {
        return sessionRepository.findFirstByMeetingIdOrderByCreatedAtDesc(meetingId)
            .orElseThrow(() -> new AiServiceException("Khong co AI session nao cho meeting " + meetingId));
    }

    private AiSessionResponse toResponse(MeetingAiSessionEntity entity) {
        return new AiSessionResponse(
            entity.getId(),
            entity.getExternalSessionId(),
            entity.getStatus(),
            entity.getStartedAt(),
            entity.getFinishedAt(),
            entity.getErrorMessage()
        );
    }
}
