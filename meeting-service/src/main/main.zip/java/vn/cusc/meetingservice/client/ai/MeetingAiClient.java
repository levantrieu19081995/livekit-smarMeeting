package vn.cusc.meetingservice.client.ai;

import vn.cusc.meetingservice.dto.ai.request.StartAiMeetingRequest;
import vn.cusc.meetingservice.dto.ai.request.StopAiMeetingRequest;
import vn.cusc.meetingservice.dto.ai.response.AiServiceSessionResponse;
import vn.cusc.meetingservice.dto.ai.response.AiServiceStatusResponse;

public interface MeetingAiClient {
    AiServiceStatusResponse health();
    AiServiceSessionResponse startMeeting(StartAiMeetingRequest request);
    AiServiceSessionResponse stopMeeting(Long meetingId, StopAiMeetingRequest request);
    AiServiceStatusResponse getMeetingStatus(Long meetingId);
}
