package vn.cusc.meetingservice.model.enums;

public enum AiSessionStatus {
    STARTING,
    RUNNING,
    COMPLETED,
    FAILED,
    STOPPED
}
